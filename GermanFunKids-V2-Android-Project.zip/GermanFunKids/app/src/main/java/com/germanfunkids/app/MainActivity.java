package com.germanfunkids.app;

import android.app.Activity;
import android.os.Bundle;
import android.webkit.WebView;
import android.webkit.WebViewClient;
import android.webkit.WebChromeClient;
import android.webkit.JavascriptInterface;
import android.speech.tts.TextToSpeech;
import android.content.Context;
import java.util.Locale;
import java.util.HashMap;

public class MainActivity extends Activity {
    private WebView webView;
    private TextToSpeech tts;
    private boolean ttsReady = false;

    @Override public void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        getWindow().setStatusBarColor(android.graphics.Color.rgb(255, 227, 125));
        getWindow().setNavigationBarColor(android.graphics.Color.rgb(255, 249, 236));
        webView = new WebView(this);
        webView.setBackgroundColor(android.graphics.Color.rgb(255, 249, 236));
        webView.getSettings().setJavaScriptEnabled(true);
        webView.getSettings().setDomStorageEnabled(true);
        webView.setWebViewClient(new WebViewClient());
        webView.setWebChromeClient(new WebChromeClient());
        webView.addJavascriptInterface(new SpeechBridge(), "AndroidTTS");
        setContentView(webView);
        tts = new TextToSpeech(this, status -> {
            if (status == TextToSpeech.SUCCESS) {
                int result = tts.setLanguage(Locale.GERMANY);
                ttsReady = result != TextToSpeech.LANG_MISSING_DATA && result != TextToSpeech.LANG_NOT_SUPPORTED;
                tts.setSpeechRate(0.78f);
            }
        });
        webView.loadUrl("file:///android_asset/index.html");
    }

    private class SpeechBridge {
        @JavascriptInterface public void speak(String text) { speak(text, 0.78f); }
        @JavascriptInterface public void speak(String text, float rate) {
            runOnUiThread(() -> {
                if (tts != null && ttsReady && text != null) {
                    tts.setSpeechRate(Math.max(0.45f, Math.min(1.0f, rate)));
                    tts.speak(text, TextToSpeech.QUEUE_FLUSH, null, "german-fun-kids");
                }
            });
        }
    }

    @Override public void onBackPressed() {
        if (webView != null && webView.canGoBack()) webView.goBack();
        else super.onBackPressed();
    }
    @Override protected void onDestroy() {
        if (webView != null) webView.destroy();
        if (tts != null) { tts.stop(); tts.shutdown(); }
        super.onDestroy();
    }
}

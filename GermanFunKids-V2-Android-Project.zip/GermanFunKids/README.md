# German Fun Kids V2 — Android project

A child-friendly, offline-first German learning app for preschool beginners.

## Version 2 features
- Animated bear mascot and positive celebrations
- German speech via Android Text-to-Speech for cards, quizzes, and phrases, with a slow playback button
- Listening quiz with picture answers
- Memory matching game
- Drag-and-drop word basket game (tap-to-select fallback for phones)
- Stars, badges, and star-gated learning levels
- Daily learning path and local progress tracking
- Eight learning topics with German words and simple English meanings
- No ads, no account, no analytics, no network permission

## Phone-only GitHub build
1. Open your existing GitHub repository.
2. Upload this ZIP to the repository root as `GermanFunKids-Android-Project.zip`, replacing the older ZIP.
3. Edit `.github/workflows/build-apk.yml` and replace its contents with the workflow in this ZIP's `.github/workflows/build-apk.yml`, then commit to `main`.
4. Open Actions and select **Build German Fun Kids APK**. Run the workflow if it does not start automatically.
5. When successful, download the `German-Fun-Kids-V2-APK` artifact. Extract the downloaded artifact ZIP on your phone and install `app-debug.apk`.

The workflow installs Android SDK platform/build tools, unpacks this project ZIP, builds with Java 17 and Gradle 8.9, and uploads the APK.

## Privacy and offline behavior
Learning content and progress are stored locally in the app's WebView local storage. The app does not request internet permission, send data to a server, show ads, or require an account. Android Text-to-Speech uses the device's installed German voice. If no German voice is installed, download one in Android's Text-to-Speech settings. Speech availability can depend on the device's installed TTS engine.

## Build note
The source ZIP is provided for building; it has not been compiled in this workspace.

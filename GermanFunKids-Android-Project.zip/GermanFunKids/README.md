# German Fun Kids — Android project

A simple, child-friendly, offline-first German learning app for preschool beginners.

## Features
- 8 topics: first words, colors, numbers, animals, greetings, food, family, and little phrases
- German words with English meanings and emoji picture prompts
- Native Android Text-to-Speech bridge for German pronunciation
- Picture-choice quiz and locally saved stars
- No account, ads, analytics, or network permission

## Build an APK with Android Studio
1. Install Android Studio on a Windows, Mac, or Linux computer.
2. Open this `GermanFunKids` folder as an existing project.
3. Allow Android Studio to install the Android SDK Platform 35 and compatible Gradle tools if prompted.
4. Wait for Gradle sync to finish.
5. Select **Build > Build Bundle(s) / APK(s) > Build APK(s)**.
6. The debug APK is usually created at `app/build/outputs/apk/debug/app-debug.apk`.
7. Copy that APK to the Android phone, open it, and allow installation from that source if Android asks.

## Speech note
The app calls Android Text-to-Speech with the German (Germany) locale. A German voice must be available on the phone. If the phone has no German voice installed, install/download one in Android's Text-to-Speech settings. Word cards and games work without speech.

## Notes
This project source is provided; an APK has not been compiled in this environment. The build requires Android Studio/Android SDK and Gradle.
